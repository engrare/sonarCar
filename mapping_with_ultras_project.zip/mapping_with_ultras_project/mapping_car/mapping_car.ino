//atmel arduino deumilanove or... (every uno (board manager))
#include <SoftwareSerial.h>
SoftwareSerial Bluetooth (2, 3);

#define SIZE 50

String encryption_chars = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`{}~";

unsigned long currentTime;

char char_data;
char text_data[SIZE];
 
int data_index = 0;

const int motor_power_pins[2] = {12, 11}; //PWM REQUREMENT
const int motor_duration_pins[2] = {10, 9};

unsigned long time_for_bluetooth_send = 0;
unsigned long time_for_go_forward = 0;

void setup() {
  for(int i = 0; i < 2; i++)
    pinMode(motor_power_pins[i], OUTPUT);
  for(int i = 0; i < 2; i++)
    pinMode(motor_duration_pins[i], OUTPUT);

  

  Serial.begin(9600);
  Bluetooth.begin(57600);
  
}

void loop() {
  currentTime = millis();

  if (Bluetooth.available()) {
    char_data = Bluetooth.read();
    //Serial.print(char_data);
    if(char_data == '|') {
      text_data[data_index] = '\0';
      if(data_index == 2) {
        //Serial.println(text_data);
      
        //String myString = String(text_data);
        //Serial.print(myString);
        //int *motor_powers = strToCoordinate(myString);
        int power_left = decodingChar(text_data[0]);
        int power_right = decodingChar(text_data[1]);
      Serial.print(power_left);
      Serial.print(" ");
      Serial.println(power_right);

        
      
        moveTank(power_left, power_right);
        //moveTank(motor_powers[0]*20, motor_powers[1]*20);
      }
      data_index = 0;
      } else {
        text_data[data_index] = char_data;
        data_index++;
      }




  } else {
    //moveTankTimebase(0, 0, 200);
  }

if(time_for_bluetooth_send + 1000 < currentTime) {
  String data = "";
  
  data = encryption_chars[20];
  data += encryption_chars[3];
  
  if(!data.length())
    data = encryption_chars[0];
  //Serial.println(data);
  Bluetooth.print(data);
  time_for_bluetooth_send = millis();
}

}

double power(double x, int y) {
    if (y == 0) {
        return 1.0;
    }
    if (y < 0) {
        x = 1 / x;
        y = -y;
    }
    double result = x;

    for (int i = 1; i < y; i++) {
        result *= x;
    }

    return result;
}

void moveTankTimedelay(int powerLeft, int powerRight, int milliseconds) {
  static int old_power_left = 0;
  static int old_power_right = 0;

  for(int i = 0; i <= milliseconds; i++) {
      moveTank(round(old_power_left + (powerLeft - old_power_left)*((float)i/milliseconds)), round(old_power_right + (powerRight - old_power_right)*((float)i/milliseconds)));
      /*Serial.print(" R: ");
      Serial.print(round(old_power_left + (powerLeft - old_power_left)*((float)i/milliseconds)));
      Serial.print(" L: ");
      Serial.println(round(old_power_right + (powerRight - old_power_right)*((float)i/milliseconds)));
      */
      delay(1);
  }
  old_power_left = powerLeft;
  old_power_right = powerRight;
}

void moveTank(int powerLeft, int powerRight) {

  /*analogWrite(motor_power_pins[0], round(powerLeft*2.55) * (powerLeft < 0 ? -1 : 1));
  analogWrite(motor_power_pins[1], round(powerRight*2.55) * (powerRight < 0 ? -1 : 1));

  
  digitalWrite(motor_duration_pins[0], powerLeft > 0);
  digitalWrite(motor_duration_pins[1], powerRight > 0);*/

}

int decodingChar(char ch) {
  return encryption_chars.indexOf(ch)*3 - 100;
}

/*void writeToRegester() {
   digitalWrite(latchPin, LOW);
   shiftOut(dataPin, clockPin, LSBFIRST, output_pwr);
   digitalWrite(latchPin, HIGH);
}*/

/*int QTRDataGet(int QTRnum) {
  //return (double)analogRead(QTRdatapins[QTRnum]) * 5 / 1023 > 4;
  return 1;
}

int voltageSensor() {
  int voltage_temp = map((double)analogRead(voltage_sensor_pin[0]), 3020, 3740, 0, 100); //11.80V - 14.20V =>  0% - 100%
  return voltage_temp < 0 ? 0 : voltage_temp > 100 ? 100 : voltage_temp;
}

int ampSensor() {
  int temp = ((double)analogRead(voltage_sensor_pin[0]) - (double)analogRead(voltage_sensor_pin[1]));
  return (temp/5 - 7)*2; // HATALARI DÜZELT
}
*/