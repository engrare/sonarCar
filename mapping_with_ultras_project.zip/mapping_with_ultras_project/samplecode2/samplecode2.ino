#include <PinChangeInt.h>
#include <PinChangeIntConfig.h>
#include <PID_Beta6.h>
#include <MotorWheel.h>
#ifndef MICROS_PER_SEC
#define MICROS_PER_SEC 1000000
#endif




irqISR(irq1,isr1);
MotorWheel leftBack(9,8,A2,A3,&irq1); // Motor PWM:Pin9, DIR:Pin8, Encoder A:Pin6, B:Pin7
irqISR(irq2,isr2);
MotorWheel rightBack(10,11,A1,A0,&irq2); // Motor PWM:Pin9, DIR:Pin8, Encoder A:Pin6, B:Pin7
irqISR(irq3,isr3);
MotorWheel leftFront(4,5,6,7,&irq3); // Motor PWM:Pin9, DIR:Pin8, Encoder A:Pin6, B:Pin7
irqISR(irq4,isr4);
MotorWheel rightFront(6,7,6,7,&irq4); // Motor PWM:Pin9, DIR:Pin8, Encoder A:Pin6, B:Pin7


void setup() {
 TCCR1B=TCCR1B&0xf8|0x01; // Pin9,Pin10 PWM 31250Hz, Silent PWM
 leftBack.setSpeedMMPS(100,LOW); //Set the pwm speed 100 direction
 leftBack.PIDEnable(KC,TAUI,TAUD,10); // used whewl1 to call the PIDEnable
 rightBack.setSpeedMMPS(100,LOW); //Set the pwm speed 100 direction
 rightBack.PIDEnable(KC,TAUI,TAUD,10); // used whewl1 to call the PIDEnable
 Serial.begin(9600);
}
void loop() {
 leftBack.PIDRegulate(); //regulate the PID
 if(millis()%500==0) {
 Serial.print("speedRPM> ");
  Serial.println(leftBack.getSpeedRPM(),DEC); //display the speed of the MotorWheel
 Serial.print("MMPS --> ");
 Serial.println(leftBack.getSpeedMMPS(),DEC); //display the speed of the motor
 //wheel1.debugger();
 }
}